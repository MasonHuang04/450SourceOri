using System;
using System.IO;
using System.Globalization;
using UsMimoTestBench;
class VerifySweep {
 static int Main(string[] args) {
  string[] records=File.ReadAllText(args[0]).Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries);
  string[] csv=File.ReadAllLines(args[1]);string[] headers=csv[0].Split(',');
  int fi=Array.IndexOf(headers,"interpolated_hz"),count=0;
  if(records.Length!=27||csv.Length!=28)throw new Exception("Missing distance records");
  foreach(string record in records){
   string[] f=record.Split(',');
   // The numerical test compresses ADC idle clocks by 144. Restore the physical
   // cadence metadata for a separate GUI parser check, then recalculate checksum.
   uint span=uint.Parse(f[8],NumberStyles.HexNumber,CultureInfo.InvariantCulture);
   f[8]=(span*144).ToString("X8");
   string prefix=String.Join(",",f,0,12)+",";int sum=0;foreach(char c in prefix)sum^=(byte)c;
   MainReport r=MainReport.Parse(prefix+sum.ToString("X2")+"\r\n");
   double expected=double.Parse(csv[++count].Split(',')[fi],CultureInfo.InvariantCulture);
   if(r.Status!="OK"||!r.InterpolationValid||Math.Abs(r.Frequency-expected)>1e-9)throw new Exception("GUI sweep mismatch "+count);
  }
  File.WriteAllText(args[2],"PASS: GUI parser accepts all 27 distance results and matches the FPGA frequency values.\r\nCadence metadata restored from compressed test clocks; this is not a new physical UART test.\r\n");
  return 0;
 }
}
