
`timescale 1ns/1ps
module tb_main_fft;
 localparam LOGN=`MF_LOGN,NFFT=1<<LOGN,VCOUNT=`MF_VALID,RAW_WORDS=`MF_RAW,INPUT_LEN=RAW_WORDS+1024;
 bit done=0;reg ac=0,fc=0,rst=1;
 initial forever begin #7;if(done)break;ac=~ac;end
 initial forever begin #10;if(done)break;fc=~fc;end
 reg start=0,window_on=0,input_run=0,av=0;reg signed [15:0] sample=0;
 wire ready;wire [31:0] seq,count,span;wire [14:0] peak_bin;wire [40:0] peak_power;wire [15:0] vmin,vmax;wire [7:0] flags;
 wire signed [31:0] delta;wire [7:0] interp_status;
 MainFftProcessor #(.LOGN(LOGN),.VALID_SAMPLES(VCOUNT),.DELTA_W(`MF_DW),.MIN_BIN(`MF_MIN),.MAX_BIN(`MF_MAX),.SAMPLE_TICKS(32)) dut(.sys_clk(ac),.fft_clk(fc),.sys_rst(rst),.fft_rst(rst),.i_start(start),.i_capture_active(window_on),.i_raw_valid(av),.i_raw_sample(sample),
 .o_done(ready),.o_seq(seq),.o_count(count),.o_span(span),.o_bin(peak_bin),.o_power(peak_power),.o_min(vmin),.o_max(vmax),.o_flags(flags),.o_delta_q16(delta),.o_interp_status(interp_status));
 reg send=0,uart_busy=0;wire [7:0] outbyte;wire valid,sending,sent;
 MainPeakReport report(.clk(ac),.rst(rst),.i_start(send),.i_tx_busy(uart_busy),.i_seq(seq),.i_count(count),.i_span(span),.i_bin(peak_bin),.i_power(peak_power),.i_min(vmin),.i_max(vmax),.i_flags(flags),.i_delta_q16(delta),.i_interp_status(interp_status),.i_fft_length(16'(NFFT)),.o_data(outbyte),.o_valid(valid),.o_busy(sending),.o_done(sent));
 reg [15:0] stim[0:INPUT_LEN-1],expected[0:INPUT_LEN/32-1];integer case_no=0,n=0,dn=0,cn=0,bn=0,fn=0,sum=0,hold_count=0,bytes=0;
 integer fft_ticks=0,begin_tick=0,process_ticks=0;
 integer captured[0:VCOUNT-1];integer cf,sf,mf,uf;string path;integer centered;
 always @(negedge ac)begin
  av=0;
  if(input_run)begin
   if(n<RAW_WORDS)begin
    sample=stim[n];av=1;n++;
   end else begin window_on=0;input_run=0;end
  end
 end
 always @(posedge ac)if(!rst)begin
  if(dut.cv)begin
   if(dut.cs!==expected[dn])$fatal(1,"CIC/FIR mismatch case=%0d index=%0d",case_no,dn);dn++;
  end
  if(dut.ram_we)begin
   if(dut.fft_busy||cn>=VCOUNT)$fatal(1,"Immutable frame overwritten");captured[cn]=dut.cs;sum+=dut.cs;
   $fwrite(cf,"%0d,%0d,%0d\n",case_no,cn,dut.cs);cn++;
  end
  if(hold_count>0)begin hold_count--;if(hold_count==0)uart_busy<=0;end
  if(valid)begin
   if(uart_busy)$fatal(1,"Reporter transmitted while UART busy");
   uart_busy<=1;hold_count=3;$fwrite(uf,"%c",outbyte);bytes++;
  end
 end
 always @(posedge fc)if(!rst)begin
  fft_ticks++;if(dut.state==dut.META)begin_tick=fft_ticks;if(dut.state==dut.REPORT)process_ticks=fft_ticks-begin_tick;
  if(dut.state==dut.FEED&&dut.fft_input_ready)begin
   if($signed(dut.ram_q)!==captured[fn]||$signed(dut.dc_mean)!==sum/VCOUNT)$fatal(1,"Read/DC mismatch");
   centered=captured[fn]-sum/VCOUNT;if(centered>32767)centered=32767;if(centered< -32768)centered=-32768;
   if($signed(dut.fft_sample)!==centered)$fatal(1,"Centering mismatch");fn++;
  end
  if(dut.power_valid)begin
   if(dut.power_bin!=bn)$fatal(1,"FFT ordering");
   $fwrite(sf,"%0d,%0d,%0d,%0d,%0d\n",case_no,bn,dut.power_re,dut.power_im,dut.power_value);bn++;
  end
 end
 initial begin
  cf=$fopen("capture.csv","w");sf=$fopen("spectrum.csv","w");mf=$fopen("metadata.csv","w");uf=$fopen("telemetry.txt","w");
  $fwrite(cf,"case,index,code\n");$fwrite(sf,"case,bin,real,imag,power\n");$fwrite(mf,"case,seq,count,span,flags,bin,power,mean,delta_q16,interp_status,process_cycles\n");
  repeat(30)@(negedge ac);#1;rst=0;
  for(case_no=0;case_no<27;case_no++)begin
   n=0;dn=0;cn=0;bn=0;fn=0;sum=0;bytes=0;
   path=$sformatf("input_%0d.mem",case_no);$readmemh(path,stim);
   path=$sformatf("expected_%0d.mem",case_no);$readmemh(path,expected);
   @(negedge ac);#1;start=1;@(negedge ac);#1;start=0;window_on=1;input_run=1;
   wait(!window_on);wait(ready);@(negedge ac);#1;
   if($isunknown({seq,count,span,peak_bin,peak_power,flags}))$fatal(1,"Unknown FFT result");
   if(seq!=case_no+1||count!=cn)$fatal(1,"Result CDC/sequence mismatch");
   begin
    if(cn!=VCOUNT||fn!=VCOUNT||bn!=NFFT/2+1||span!=(VCOUNT-1)*32)$fatal(1,"Frame length/cadence");
    if((flags & 8'hef)!=0)$fatal(1,"Unexpected acquisition/FFT flags %h",flags);
    // A weak out-of-band peak may legitimately set flag bit 4.
   end
   send=1;wait(sending);@(negedge ac);#1;send=0;wait(sent);#1;
   if(bytes!=81)$fatal(1,"Report must be 81 bytes");
   $fwrite(mf,"%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d\n",case_no,seq,count,span,flags,peak_bin,peak_power,dut.dc_mean,delta,interp_status,process_ticks);
   $display("PASS MAIN FFT case=%0d count=%0d bin=%0d flags=%h",case_no,count,peak_bin,flags);
  end
  $fclose(cf);$fclose(sf);$fclose(mf);$fclose(uf);$display("PASS MAIN FFT PIPELINE");done=1;
 end
 initial begin #100000000;if(!done)$fatal(1,"Global timeout");end
endmodule
