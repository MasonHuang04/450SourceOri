from pathlib import Path
import json,re,hashlib,shutil,csv,zipfile,html
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
A=Path(__file__).resolve().parent;P=A/'project';V=P/'02_RTL/V0';T=V/'Simulation/FFT/results/main';O=A/'report';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sta=(V/'output_files/UsMimoTestBench.sta.summary').read_text()
timings=[dict(check=n,slack_ns=float(s),tns_ns=float(t)) for n,s,t in re.findall(r'Type\s+:\s+([^\n]+)\nSlack\s+:\s+([\d.-]+)\nTNS\s+:\s+([\d.-]+)',sta)]
assert len(timings)==84 and all(t['slack_ns']>=0 and t['tns_ns']==0 for t in timings)
rpt=(V/'output_files/UsMimoTestBench.sta.rpt').read_text(errors='replace')
section=rpt[rpt.index('; Unconstrained Paths Summary'):];section=section[:section.index('; Clock Status Summary')]
assert len(re.findall(r'; (?:Illegal|Unconstrained)[^;]+;\s*0\s*;\s*0\s*;',section))==6
assert 'Quartus Prime Shell was successful. 0 errors' in (A/'compile_main.log').read_text(errors='replace')
main=json.loads((T/'fft/checks.json').read_text());interp=json.loads((T/'interpolation/checks.json').read_text());assert main['pass_all'] and interp['pass_all']
for sub,marker in [('system','PASS MAIN LONG FRAME'),('short','PASS MAIN SHORT TOP'),('io','PASS MAIN IO')]:
 log=(T/sub/'simulation.log').read_text(errors='replace');assert marker in log and '** Fatal' not in log and '** Error' not in log
assert (A/'sw_checks_final/checks.txt').read_text(encoding='utf-8-sig').count('PASS ')==5
cases=[r for r in main['cases'] if r['flags']==0]
with (O/'main_comparison.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['input_hz','peak_hz','error_hz','interpolated_hz','interpolated_error_hz','delta_q16']);w.writeheader();w.writerows({k:r[k] for k in w.fieldnames} for r in cases)
fig,ax=plt.subplots(1,2,figsize=(12,4.4),layout='constrained')
sw=[r for r in interp['cases'] if r['kind']=='single_tone_numpy_spectrum']
ax[0].scatter([r['input_hz'] for r in sw],[r['coarse_error_hz'] for r in sw],s=9,alpha=.28,color='#8996a4',label='Largest FFT bin')
ax[0].scatter([r['input_hz'] for r in sw],[r['fine_error_hz'] for r in sw],s=10,alpha=.6,color='#007d91',label='FPGA log-parabolic interpolation')
ax[0].set(xlabel='Input frequency (Hz)',ylabel='Frequency error (Hz)',title='764 single-tone spectrum tests');ax[0].grid(alpha=.2);ax[0].legend(loc='lower right',fontsize=8)
spec=np.genfromtxt(T/'fft/spectrum.csv',delimiter=',',names=True,dtype=np.int64);s=spec[spec['case']==1];r=cases[1];k=r['peak_bin'];df=interp['bin_hz'];power=s['power'][k-1:k+2].astype(float);db=10*np.log10(power/power[1]);x=np.linspace(-1,1,401);fit=np.polyfit([-1,0,1],db,2)
ax[1].plot((k+x)*df,np.polyval(fit,x),color='#007d91',label='3-point log parabola');ax[1].scatter((k+np.array([-1,0,1]))*df,db,color='#c67b29',s=45,label='Actual Main RTL FFT powers',zorder=3)
ax[1].axvline(100,color='#333333',ls=':',label='Input: 100 Hz');ax[1].axvline(r['interpolated_hz'],color='#007d91',ls='--',label=f"Interpolated: {r['interpolated_hz']:.3f} Hz")
ax[1].set(xlabel='Frequency (Hz)',ylabel='Relative power (dB)',title=f"Main RTL: {r['peak_hz']:.3f} -> {r['interpolated_hz']:.3f} Hz");ax[1].grid(alpha=.2);ax[1].legend(fontsize=8)
fig.savefig(O/'comparison.png',dpi=160);plt.close(fig)
shutil.copy2(A/'ui.png',O/'ui.png')
fit=(V/'output_files/UsMimoTestBench.fit.summary').read_text()
summary=dict(date='2026-10-20',pass_all=True,scope='Main FPGA log-power peak interpolation; standalone experiments unchanged; hardware measurement pending',
 timing_checks=timings,min_slack_ns=min(t['slack_ns'] for t in timings),unconstrained_setup_hold=0,
 main_fft=main,interpolation=interp,fit_summary=fit,main_sof_sha256=sha(V/'output_files/UsMimoTestBench.sof'),
 ui_exe_sha256=sha(P/'03_SW/UsMimoTestBench/bin/Release/UsMimoTestBench.exe'),
 algorithm='delta=.5*(log2(Pleft)-log2(Pright))/(log2(Pleft)-2*log2(Pcenter)+log2(Pright)); clamp +/-0.5; signed Q16',
 limitations=['No physical resolution increase; FFT bin spacing remains 4.371007 Hz.','Sweeps feed NumPy-derived quantized spectra to the actual RTL interpolation module.','Main pipeline tests use all samples with compressed idle clocks; not full real-time analog simulation.','No new hardware measurement; no multi-target-resolution guarantee.'])
(O/'checks.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
small={k:v for k,v in summary.items() if k not in ['main_fft','interpolation','fit_summary']}
(V/'output_files/build_checks.json').write_text(json.dumps(small,ensure_ascii=False,indent=2),encoding='utf-8')
rows=''.join(f"<tr><td>{r['input_hz']:g}</td><td>{r['peak_hz']:.6f}</td><td>{r['interpolated_hz']:.6f}</td><td>{r['error_hz']:+.6f}</td><td>{r['interpolated_error_hz']:+.6f}</td></tr>" for r in cases)
h=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>Main FPGA peak interpolation</title><style>
body{{max-width:1180px;margin:40px auto;padding:0 24px;font:17px/1.7 'Microsoft YaHei',sans-serif;color:#24384a;background:#f5f8fb}}h1{{font-size:32px}}h2{{font-size:22px;margin-top:34px}}.card{{background:white;padding:22px;border:1px solid #d8e2eb;border-radius:12px;margin:20px 0}}.flow{{font-size:19px;color:#006c80}}table{{border-collapse:collapse;width:100%}}td,th{{padding:10px;border-bottom:1px solid #d8e2eb;text-align:right}}img{{width:100%;height:auto}}a{{color:#006c9c}}code{{background:#e9eff4;padding:3px}}.muted{{color:#526577;font-size:15px}}</style>
<h1>Main：FPGA 内的三点峰值插值</h1><p>2026-10-20 · 本地实现与验证 · 新 Main SOF + M2 上位机</p>
<div class="card flow">采样 → CIC /32 → Kaiser4 → 8192 点 FFT → 最大功率频点 → <b>三点对数插值（新增）</b> → UART</div>
<p>插值发生在 FFT <b>之后</b>，利用峰值及左右邻点估计峰顶位置。log、除法和偏移均在 FPGA 完成；电脑只解析 Q16 结果并换算 Hz。Chirp、RX 250 ms、采样率、8192点和两个独立实验保持原样。</p>
<div class="card"><b>验证通过：</b>完整 Main 数字处理分支、1136组插值检查、71614点原始数据/M2回传、短ADC与真实2 Mbaud UART、生产C#解析。Quartus全编译通过；84项时序检查无负余量，最小 <b>+{summary['min_slack_ns']:.3f} ns</b>，无未约束的Setup/Hold路径。</div>
<h2>完整 Main RTL 的前后对比</h2><table><tr><th>输入 Hz</th><th>原频点 Hz</th><th>插值 Hz</th><th>原误差 Hz</th><th>插值误差 Hz</th></tr>{rows}</table>
<p class="muted">250 Hz案例叠加700 Hz干扰；99.6 Hz案例叠加抽取后的混叠频率附近干扰。异常削顶、短帧、空帧都不会被当作有效插值。功率仍报告原最大频点的功率。</p>
<img src="comparison.png"><p class="muted">左图：NumPy生成量化频谱，实际RTL完成插值（191频率×4相位）；右图：完整Main RTL产生的100 Hz频谱。左图最大绝对误差从2.1806 Hz降至0.1404 Hz；另60组25 dB单音输入最大插值误差约0.1479 Hz。测试条件不同于论文图中的毫米测距指标。</p>
<h2>运算量与资源</h2><p>频率格仍为4.371007 Hz。新增插值最大140个50 MHz周期，约2.8 μs；不是减少现有FFT运算。资源为7190 ALM（13%）、31 DSP（20%）、307 RAM块（45%）；相比旧Main多584 ALM、874寄存器和1 DSP，块RAM用量不变。</p>
<h2>使用方法</h2><ol><li>在Programmer重新下载 <a href="../../../02_RTL/V0/output_files/UsMimoTestBench.sof">Main 的 UsMimoTestBench.sof</a>。</li><li>运行 <a href="../../../03_SW/RunMain.cmd">03_SW/RunMain.cmd</a>，选主板COM口。</li><li>外部发生器向RX输入连续100 Hz正弦，使用此前已验证的幅度与接线；点击“应用并采集一次”。</li><li>比较界面的“FPGA插值”“原频点”和误差；参考频率只用于评价，不参与估计。</li></ol>
<p>新软件兼容旧M1；旧固件会标明“未提供插值”。新固件使用76字节M2，需配套新版查看器。尚未进行这版固件的实板验证。</p><img src="ui.png"><p class="muted">界面截图为离线合成演示，不是实板测量。</p>
<h2>可复现入口</h2><p>在Simulation/FFT中运行 <code>python run_main.py --interp</code>、<code>--fast-memory</code>、<code>--system</code>、<code>--short</code> 或 <code>--io</code>。沿用原来的两个FFT测试台文件。</p>
<p><a href="checks.json">检查数据</a> · <a href="main_comparison.csv">对比CSV</a> · <a href="evidence.zip">源码/日志证据</a> · <a href="../../../02_RTL/V0/README_main_2026-10-17.md">算法、协议与使用说明</a></p>
<p class="muted">插值提升孤立峰的位置估计，不改变采集时长或物理分辨能力；不能保证噪声、多目标、非稳态或实板条件下都达到上述误差。没有新增FPGA混频或距离换算。</p></html>'''
(O/'report.html').write_text(h,encoding='utf-8')
print(json.dumps(dict(timing_checks=len(timings),minimum_slack_ns=summary['min_slack_ns'],report=str(O/'report.html')),indent=2))
