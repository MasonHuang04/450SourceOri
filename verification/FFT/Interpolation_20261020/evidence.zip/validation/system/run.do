onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/SysLib.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/DSPLib.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/SourceCode/MainSettings.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/RxDepack.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/MainTxPack.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/MainRxController.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/TxModel.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/TempModel.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/MainTest.vhd}
vlog -sv +define+FFT_USE_INTEL_RAM +define+MAIN_SYSTEM_TOP {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/MainPeakReport.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/MainCicDecimator.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/MainFrameRam.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/MainFftProcessor.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/MainWaveFifo_model.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/fft_tdp_store.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/kaiser4_rfft.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/fft_power_peak.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/system/units/main_peak_interpolator.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/tb_fft_board.sv}
vsim -t 1ps -L altera_mf work.tb_main_top
set NumericStdNoWarnings 1
set StdArithNoWarnings 1
run -all
quit -code 0 -force
