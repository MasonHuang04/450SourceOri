onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/io/units/SysLib.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/io/units/UARTController.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/io/units/RxDepack.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/io/units/MainTxPack.vhd}
vlog -sv +define+MAIN_IO_TEST {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/io/units/MainPeakReport.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/io/units/MainAdcBridge.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/io/units/MainWaveFifo.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/tb_fft_board.sv}
vsim -t 1ps -L altera_mf work.tb_main_io
set NumericStdNoWarnings 1
set StdArithNoWarnings 1
run -all
quit -code 0 -force
