onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vlog -sv +define+INTERP_TEST {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/results/main/interpolation/units/main_peak_interpolator.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/peak_interp_20261020/project/02_RTL/V0/Simulation/FFT/tb_fft_plot.sv}
vsim work.tb_interpolation
run -all
quit -code 0 -force
