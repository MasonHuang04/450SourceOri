onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vlog -sv +define+FFT_USE_INTEL_RAM +define+MF_LOGN=10 +define+MF_VALID=672 +define+MF_DW=9 +define+MF_MIN=1 +define+MF_MAX=14 +define+MF_RAW=21770 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/distance_sweep_20261021/run/units/MainFftProcessor.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/distance_sweep_20261021/run/units/MainPeakReport.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/distance_sweep_20261021/run/units/MainCicDecimator.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/distance_sweep_20261021/run/units/MainFrameRam.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/distance_sweep_20261021/run/units/kaiser4_rfft.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/distance_sweep_20261021/run/units/fft_tdp_store.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/distance_sweep_20261021/run/units/fft_power_peak.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/distance_sweep_20261021/run/units/main_peak_interpolator.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/distance_sweep_20261021/run/tb_distance_sweep.sv}
vsim -t 1ps -L altera_mf work.tb_main_fft
run -all
quit -code 0 -force
