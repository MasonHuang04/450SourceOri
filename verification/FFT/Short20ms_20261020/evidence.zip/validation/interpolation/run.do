onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vlog -sv +define+INTERP_TEST +define+MF_LOGN=10 +define+MF_VALID=672 +define+MF_DW=9 +define+MF_MIN=1 +define+MF_MAX=14 +define+MF_RAW=21770 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/Simulation/FFT/results/main/interpolation/units/main_peak_interpolator.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/Simulation/FFT/tb_fft_plot.sv}
vsim work.tb_interpolation
run -all
quit -code 0 -force
