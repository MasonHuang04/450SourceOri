from pathlib import Path
import json,re,hashlib,csv,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
A=Path(__file__).resolve().parent;P=A/'project';V=P/'02_RTL/V0';T=V/'Simulation/FFT/results/main';R=Path('E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench');O=A/'report';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
main=json.loads((T/'fft/checks.json').read_text());ip=json.loads((T/'interpolation/checks.json').read_text());old=json.loads((A/'baseline_profile/Simulation/FFT/results/main/fft/checks.json').read_text())
assert main['pass_all'] and ip['pass_all'] and old['pass_all'] and main['ram_model']=='Intel altsyncram'
meta=np.genfromtxt(A/'baseline_profile/Simulation/FFT/results/main/fft/metadata.csv',delimiter=',',names=True,dtype=np.int64)
before=int(meta['process_cycles'][0])/50000;after=main['cases'][0]['process_ms'];assert before==4.83692 and after==.4686
sta=(V/'output_files/UsMimoTestBench.sta.summary').read_text();timing=[dict(check=n,slack_ns=float(s),tns_ns=float(t)) for n,s,t in re.findall(r'Type\s+:\s+([^\n]+)\nSlack\s+:\s+([\d.-]+)\nTNS\s+:\s+([\d.-]+)',sta)]
assert len(timing)==84 and all(r['slack_ns']>=0 and r['tns_ns']==0 for r in timing)
sta_text=(V/'output_files/UsMimoTestBench.sta.rpt').read_text(errors='replace');section=sta_text[sta_text.index('; Unconstrained Paths Summary'):];section=section[:section.index('; Clock Status Summary')]
assert len(re.findall(r'; (?:Illegal|Unconstrained)[^;]+;\s*0\s*;\s*0\s*;',section))==6
assert 'Quartus Prime Shell was successful. 0 errors' in (A/'compile_main.log').read_text(errors='replace')
for sub,marker in [('fft','PASS MAIN FFT PIPELINE'),('interpolation','PASS FPGA INTERPOLATION'),('system','PASS MAIN LONG FRAME'),('short','PASS MAIN SHORT TOP'),('io','PASS MAIN IO'),('tx','PASS MAIN TX PARAMETERS AND STARTUP')]:
 text=(T/sub/'simulation.log').read_text(errors='replace');assert marker in text and '** Fatal' not in text and '** Error' not in text,sub
assert (A/'sw_checks/checks.txt').read_text(encoding='utf-8-sig').count('PASS ')==6
rows=[]
for new,prev in zip(main['cases'],old['cases']):
 if new['flags']==0:rows.append(dict(input_hz=new['input_hz'],long_hz=prev['interpolated_hz'],short_hz=new['interpolated_hz'],short_error_hz=new['interpolated_error_hz']))
with (O/'comparison.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
fig,ax=plt.subplots(1,2,figsize=(11.8,4.3),layout='constrained')
ax[0].barh(['Long frame\n8192 / 8192','Short frame\n672 / 1024'],[before,after],color=['#8297a8','#087c91']);ax[0].invert_yaxis();ax[0].set(xlabel='Digital processing time at 50 MHz (ms)',xlim=(0,5.6),title='Measured RTL processing latency')
for i,value in enumerate([before,after]):ax[0].text(value+.08,i,f'{value:.3f} ms',va='center')
ax[0].grid(axis='x',alpha=.2)
points=[r for r in ip['cases'] if r['kind']=='single_tone_numpy_spectrum']
ax[1].scatter([r['input_hz'] for r in points],[r['fine_error_hz'] for r in points],s=12,color='#087c91',alpha=.65,label='18.77 ms + interpolation')
previous=json.loads((R/'verification/FFT/Interpolation_20261020/checks.json').read_text(encoding='utf-8'))['interpolation']['cases'];previous=[r for r in previous if r['kind']=='single_tone_numpy_spectrum']
ax[1].scatter([r['input_hz'] for r in previous],[r['fine_error_hz'] for r in previous],s=7,color='#8297a8',alpha=.4,label='228.78 ms + interpolation')
ax[1].axhline(0,color='black',lw=.6);ax[1].set(xlabel='Input frequency (Hz)',ylabel='Frequency error (Hz)',title='Short windows lose low-frequency accuracy');ax[1].grid(alpha=.2);ax[1].legend(fontsize=8)
fig.savefig(O/'comparison.png',dpi=160);plt.close(fig);shutil.copy2(A/'ui_short.png',O/'ui.png')
checks=dict(date='2026-10-20',implementation_pass=True,low_frequency_accuracy_guaranteed=False,profile=main['profile'],
 processing_before_ms=before,processing_after_ms=after,speed_ratio=before/after,
 effective_window_ms=main['observation_ms'],raw_samples=5442,uart_bytes=11029,uart_line_time_ms=11029*10/2e6*1000,
 timing_checks=timing,minimum_slack_ns=min(r['slack_ns'] for r in timing),unconstrained_setup_hold=0,
 main_fft=main,interpolator=ip,long_frame_comparison=rows,fit_summary=(V/'output_files/UsMimoTestBench.fit.summary').read_text(),
 main_sof_sha256=sha(V/'output_files/UsMimoTestBench.sof'),ui_exe_sha256=sha(P/'03_SW/UsMimoTestBench/bin/Release/UsMimoTestBench.exe'),
 scope='RTL and software tests; no new hardware measurement. 19ms-equivalent system test compresses idle clocks. Numeric sweeps provide NumPy spectra to actual RTL interpolator.',
 limitations=['25Hz has fewer than 0.5 cycles and is unreliable.','Interpolation cannot reconstruct missing time samples or guarantee narrow-band resolution.','Actual echo overlap/settling may be shorter than this bench window.','Continuous UI mode still waits one second between complete frames.'])
(O/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
(V/'output_files/build_checks.json').write_text(json.dumps({k:v for k,v in checks.items() if k not in ['main_fft','interpolator','fit_summary']},ensure_ascii=False,indent=2),encoding='utf-8')
table=''.join(f"<tr><td>{r['input_hz']:g}</td><td>{r['long_hz']:.6f}</td><td>{r['short_hz']:.6f}</td><td>{r['short_error_hz']:+.6f}</td></tr>" for r in rows)
h=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>Main Short FFT</title><style>body{{max-width:1150px;margin:36px auto;padding:0 24px;font:17px/1.7 'Microsoft YaHei',sans-serif;background:#f5f8fb;color:#24384a}}h1{{font-size:32px}}h2{{font-size:23px}}.card{{background:white;border:1px solid #d4dfe8;border-radius:12px;padding:20px;margin:22px 0}}.warning{{background:#fff4de;border-left:5px solid #d68c13;padding:16px}}table{{border-collapse:collapse;width:100%}}td,th{{border-bottom:1px solid #d7e0e8;padding:10px;text-align:right}}img{{width:100%;height:auto}}.muted{{font-size:14px;color:#516476}}a{{color:#087492}}code{{background:#e5edf3;padding:3px}}</style>
<h1>Main短窗FFT：与20 ms Chirp配合</h1><p>2026-10-20 · 用户选择缩短到Chirp时长，并接受低频精度下降</p>
<div class="warning"><b>插值不能填补缺失的观测时间。</b> 25 Hz在有效数据中不足半周期，短窗可能把它估计到40–49 Hz附近。当前“实现验证通过”不代表25–500 Hz全范围达到旧长窗精度。</div>
<div class="card"><b>TX保持38–42 kHz / 20 ms / 幅度0.25</b><br>RX延迟1 ms后采集19 ms → CIC /32 → 672有效点（18.767 ms）→ Kaiser4 → 补352个零到1024 → FFT → 峰值插值 → UART M3。</div>
<table><tr><th>项目</th><th>旧长窗Main</th><th>新短窗Main</th></tr><tr><td>RX窗口</td><td>250 ms</td><td>19 ms</td></tr><tr><td>有效点 / FFT长度</td><td>8192 / 8192</td><td>672 / 1024</td></tr><tr><td>有效观测时长</td><td>228.780 ms</td><td>18.767 ms</td></tr><tr><td>数字处理耗时</td><td>{before:.5f} ms</td><td>{after:.5f} ms</td></tr><tr><td>频率格</td><td>4.371007 Hz</td><td>34.968058 Hz</td></tr><tr><td>原始回传点</td><td>71614</td><td>5442</td></tr></table>
<p>数字处理以50 MHz RTL周期计数，包含去直流、加窗/FFT、功率与插值，不含采集和UART；约快{before/after:.2f}倍。新UART线路时间约55.15 ms，单次采集/处理/传输约75 ms量级，电脑端额外延迟另计。连续模式仍有约1秒的软件等待。</p>
<img src="comparison.png"><p class="muted">左：实际RTL状态机计时，长窗使用已验证等延迟行为内存，短窗使用Intel内存模型；右：191频率×4相位，NumPy生成量化频谱，实际RTL完成插值。FFT后的插值没有增加真实采集信息。</p>
<h2>完整数字处理分支的例子</h2><table><tr><th>输入Hz</th><th>长窗插值Hz</th><th>短窗插值Hz</th><th>短窗误差Hz</th></tr>{table}</table>
<p>100、250、500 Hz示例较接近输入；25 Hz示例明显错误，而且插值结果甚至可能比原整数频点偏差更大。75 Hz也有明显的相位相关误差。不能从一个100 Hz例子推出全频段精度。250 Hz案例含700 Hz干扰，99.6 Hz案例含抽取镜像附近干扰。</p>
<h2>验证与资源</h2><p>Intel内存下的全部FFT实虚部/功率与独立定点参考逐点一致；短/空帧和削顶正确标记。19 ms等效完整数据回传为21770个原始输入、5442个回传点、11029字节；系统测试压缩空闲拍，另做短ADC SPI和真实2Mbaud逐位串口检查。1136组插值检查、生产C#分片解析/长度换算/兼容性检查通过。</p>
<p>全编译通过，84项时序检查均非负，最小余量<b>+{checks['minimum_slack_ns']:.3f} ns</b>（余量较小）；主时钟165 MHz保持原样。资源7067 ALM、31 DSP、272 RAM块；原长窗为7190 ALM、31 DSP、307 RAM块。尚未实板验证。</p>
<h2>上板使用</h2><ol><li>重新下载<a href="../../../02_RTL/V0/output_files/UsMimoTestBench.sof">Main SOF</a>。</li><li>运行配套<a href="../../../03_SW/RunMain.cmd">RunMain.cmd</a>，选COM口。</li><li>先接外部100 Hz连续小幅正弦到主板RX，点击“应用并采集一次”。TX仍可接示波器看20 ms Chirp。</li><li>新界面应显示约5442点波形；低频结果呈橙色“短窗低频，仅供参考”。只输入参考频率不会改变估计值。</li></ol>
<p>本次新增M3报文显式携带FFT长度，避免沿用8192点的频率换算。旧固件/旧查看器不能直接用于本次短窗测试；请配套更新。</p><img src="ui.png"><p class="muted">截图是离线合成演示，非主板实测。</p>
<h2>源码与证据</h2><p>配置：<code>Simulation/FFT/main_settings.json</code>。仍使用同一个QPF和原有测试台。<code>configure_main.py</code>同步生成RTL参数、ROM及软件默认配置块。</p>
<p><a href="checks.json">全部检查数据</a> · <a href="comparison.csv">对比CSV</a> · <a href="evidence.zip">源码和日志</a> · <a href="../../../02_RTL/V0/README_main_2026-10-17.md">参数/协议/复现说明</a> · <a href="../../Archive/before_short20ms_20261020.zip">修改前完整配套备份</a></p>
<p class="muted">当前仍只找最强峰；没有新增混频、传播补偿、多峰或距离计算。20ms声路的有效拍频时段还会受传播与模拟滤波影响，需实测后再确定。</p></html>'''
(O/'report.html').write_text(h,encoding='utf-8')
print(json.dumps(dict(report=str(O/'report.html'),timing_checks=len(timing),minimum_slack_ns=checks['minimum_slack_ns'],speedup=before/after),indent=2))
