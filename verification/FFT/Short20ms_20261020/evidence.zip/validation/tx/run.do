onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/Simulation/FFT/results/main/tx/units/SysLib.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFAdd/FPFAdd/dspba_library_package.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFAdd/FPFAdd/dspba_library.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFAdd/FPFAdd/FPFAdd_0002.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFAdd/FPFAdd.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFSub/FPFSub/FPFSub_0002.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFSub/FPFSub.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFMult/FPFMult/FPFMult_0002.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFMult/FPFMult.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFDiv/FPFDiv/FPFDiv_0002.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFDiv/FPFDiv.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFCos/FPFCos/FPFCos_0002.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFCos/FPFCos.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFFP32ToInt32/FPFFP32ToInt32/FPFFP32ToInt32_0002.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFFP32ToInt32/FPFFP32ToInt32.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFInt32ToFP32/FPFInt32ToFP32/FPFInt32ToFP32_0002.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FPFInt32ToFP32/FPFInt32ToFP32.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/Simulation/FFT/results/main/tx/units/DSPLib.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/SourceCode/DSP/FIFO.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/Simulation/FFT/results/main/tx/units/ChirpWaveGen.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/Simulation/FFT/results/main/tx/units/MainTxController.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/Simulation/FFT/results/main/tx/units/MainRxController.vhd}
vlog -sv {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/Simulation/FFT/results/main/tx/units/MainAdcBridge.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/Simulation/FFT/results/main/tx/units/ScopeAdc27m5.sv}
vlog -sv +define+MAIN_TX_PARAMETERS {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/main_short20_20261020/project/02_RTL/V0/Simulation/FFT/tb_fft_board.sv}
vsim -t 1ps -L altera_mf -L altera_lnsim -L lpm work.tb_main_tx_parameters
set NumericStdNoWarnings 1
set StdArithNoWarnings 1
run -all
quit -code 0 -force
