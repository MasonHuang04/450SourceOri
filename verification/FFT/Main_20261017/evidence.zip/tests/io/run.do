onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/SysLib.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/UARTController.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/RxDepack.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainTxPack.vhd}
vlog -sv +define+MAIN_IO_TEST {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainPeakReport.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainAdcBridge.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainWaveFifo.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/tb_fft_board.sv}
vsim -t 1ps -L altera_mf work.tb_main_io
set NumericStdNoWarnings 1
set StdArithNoWarnings 1
run -all
quit -code 0 -force
