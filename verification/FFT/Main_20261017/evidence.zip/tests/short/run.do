onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/SysLib.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSPLib.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainSettings.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/RxDepack.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainTxPack.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainRxController.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/results/main/short/TxModel.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/results/main/short/TempModel.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/results/main/short/MainTest.vhd}
vlog -sv +define+FFT_USE_INTEL_RAM +define+MAIN_SHORT_TOP {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainPeakReport.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainCicDecimator.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainFrameRam.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainFftProcessor.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainWaveFifo.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/fft_tdp_store.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/kaiser4_rfft.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/fft_power_peak.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/ScopeAdc27m5.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainAdcBridge.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/tb_fft_board.sv}
vsim -t 1ps -L altera_mf work.tb_main_top
set NumericStdNoWarnings 1
set StdArithNoWarnings 1
force -deposit /tb_main_top/dut/uRx/cTick 16#ffb6c20 0
run -all
quit -code 0 -force
