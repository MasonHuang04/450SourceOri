library IEEE;
use IEEE.Std_Logic_1164.ALL;
use IEEE.Std_Logic_Arith.ALL;
use IEEE.Std_Logic_Unsigned.ALL;
use work.SysLib.ALL;
use work.DSPLib.ALL;

entity MainTxController is
	port(
		--input clock
		iClk : in std_logic;
		iRst : in std_logic := '1';
		
		--control
		iStart : in std_logic := '0'; --signal to start sending a chirp
		oBusy : out std_logic := '0';
		
		--chirp parameters
		iSQWaveEn : in std_logic := '0';
		iDownSampleRate : in integer range 0 to 65535 := 0; --sampling rate = 165M / (DownSampleRate + 1)
		iDataResolution : in integer range 0 to 31 := 14;
		iFc : in std_logic_vector(31 downto 0) := x"471c4000"; --center freq, F32, Hz, def = 40000
		iBW : in std_logic_vector(31 downto 0) := x"459c4000"; --bandwidth, F32, Hz, def = 5000
		iTc : in std_logic_vector(31 downto 0) := x"3c23d70a"; --time duration for chirp, F32, s, def = 0.01
		iA : in std_logic_vector(31 downto 0) := x"3f800000"; --amp ratio, F32, def = 1.0f for full range
		
		--mux control
		iMuxSel : in std_logic_vector(2 downto 0) := "000"; --bit 2 for FLT, 1 downto 0 for gain. 000 for div 1 no flt
		
		--DA interface
		oDA_PD : out std_logic := '0';
		oDA_CLK : out std_logic;
		oDA_D : out std_logic_vector(13 downto 0);
		
		--mux
		oTX_MUX_EN : out std_logic := '1';
		oTX_MUX_A : out std_logic_vector(2 downto 0) := "000";
		
		--LED indicators
		oLED_CHIRP : out std_logic := '0';
		oLED_TX_FLT : out std_logic := '0';
		oLED_TX_DIV1 : out std_logic := '0';
		oLED_TX_DIV2 : out std_logic := '0';
		oLED_TX_DIV4 : out std_logic := '0';
		oLED_TX_DIV8 : out std_logic := '0'
	);
end entity MainTxController;

architecture model of MainTxController is
begin
 oDA_PD<='0';oDA_CLK<=iClk;oDA_D<=(others=>'0');oTX_MUX_EN<='1';oTX_MUX_A<=iMuxSel;
 process begin oBusy<='0';wait until rising_edge(iStart);
  assert iFc=x"48435000" and iBW=x"469c4000" and iTc=x"3da3d70a" report "TX defaults changed" severity failure;
  oBusy<='1';wait for 20 us;oBusy<='0';wait until iStart='0';end process;
end architecture;
