
library IEEE;
use IEEE.Std_Logic_1164.ALL;
use IEEE.Std_Logic_Arith.ALL;
use IEEE.Std_Logic_Unsigned.ALL;

entity MainTMP117Controller is
	port(
		iClk : in std_logic; --PCLK freq
		iRst : in std_logic;
		
		iAddr : in std_logic_vector(7 downto 0) := x"48";
		
		oDataValid : out std_logic := '0';
		oTempData : out std_logic_vector(15 downto 0) := x"0000";
		
		
		oTmp_SCL : out std_logic := '1';
		ioTmp_SDA : inout std_logic := 'Z'
	);
end entity MainTMP117Controller;

architecture model of MainTMP117Controller is
begin oTempData<=x"0C80";oDataValid<='1';oTmp_SCL<='1';ioTmp_SDA<='Z';end architecture;
