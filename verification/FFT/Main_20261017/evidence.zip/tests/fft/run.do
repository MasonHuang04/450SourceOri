onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vlog -sv +define+MAIN_FFT_TEST {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainFftProcessor.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainPeakReport.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainCicDecimator.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainFrameRam.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/kaiser4_rfft.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/fft_tdp_store.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/fft_power_peak.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/tb_fft_plot.sv}
vsim -t 1ps -L altera_mf work.tb_main_fft
run -all
quit -code 0 -force
