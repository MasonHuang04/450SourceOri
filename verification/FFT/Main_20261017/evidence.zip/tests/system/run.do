onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/SysLib.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSPLib.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainSettings.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/RxDepack.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainTxPack.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainRxController.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/results/main/system/TxModel.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/results/main/system/TempModel.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/results/main/system/MainTest.vhd}
vlog -sv +define+FFT_USE_INTEL_RAM +define+MAIN_SYSTEM_TOP {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainPeakReport.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainCicDecimator.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainFrameRam.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainFftProcessor.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/results/main/system/MainWaveFifo_model.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/fft_tdp_store.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/kaiser4_rfft.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/fft_power_peak.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/tb_fft_board.sv}
vsim -t 1ps -L altera_mf work.tb_main_top
set NumericStdNoWarnings 1
set StdArithNoWarnings 1
run -all
quit -code 0 -force
