onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/SysLib.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFAdd/FPFAdd/dspba_library_package.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFAdd/FPFAdd/dspba_library.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFAdd/FPFAdd/FPFAdd_0002.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFAdd/FPFAdd.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFSub/FPFSub/FPFSub_0002.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFSub/FPFSub.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFMult/FPFMult/FPFMult_0002.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFMult/FPFMult.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFDiv/FPFDiv/FPFDiv_0002.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFDiv/FPFDiv.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFCos/FPFCos/FPFCos_0002.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFCos/FPFCos.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFFP32ToInt32/FPFFP32ToInt32/FPFFP32ToInt32_0002.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFFP32ToInt32/FPFFP32ToInt32.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFInt32ToFP32/FPFInt32ToFP32/FPFInt32ToFP32_0002.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FPFInt32ToFP32/FPFInt32ToFP32.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSPLib.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/DSP/FIFO.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/ChirpWaveGen.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainTxController.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainRxController.vhd}
vlog -sv {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/MainAdcBridge.sv} {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/ScopeAdc27m5.sv}
vlog -sv +define+MAIN_TX_PARAMETERS {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/Simulation/FFT/tb_fft_board.sv}
vsim -t 1ps -L altera_mf -L altera_lnsim -L lpm work.tb_main_tx_parameters
set NumericStdNoWarnings 1
set StdArithNoWarnings 1
run -all
quit -code 0 -force
