from pathlib import Path
import sys,json,subprocess,struct,math,random
A=Path(__file__).resolve().parent;P=A/'project';S=P/'02_RTL/V0/SourceCode';O=A/'measurement_tests';O.mkdir(exist_ok=True)
sys.path.insert(0,str(P/'02_RTL/V0/Simulation'))
from source_units import SourceTree
tree=SourceTree(S,O);refs=[]
bits=lambda f:int.from_bytes(struct.pack('>f',f),'big')
def scaled(b,s):
 f=struct.unpack('>f',int(b).to_bytes(4,'big'))[0]
 return None if not math.isfinite(f) or f<0 else int(math.floor(f*s+.5))
def add(temp=25,hz=145.8,bw=4000,duration=.02,ts=0,flags=0,istat=0,chirp=1,bw_bits=None,t_bits=None):
 q=int(math.floor(hz*1000*3*65536*1024/107421875+.5));k=int(math.floor(q/65536+.5));delta=q-k*65536
 if istat or flags:delta=0;q=k*65536
 fm=(q*107421875+1024*98304)//(1024*196608)
 bb=bits(bw) if bw_bits is None else bw_bits;tb=bits(duration) if t_bits is None else t_bits
 bm=scaled(bb,1000);tu=scaled(tb,1000000);raw=int(round(temp*128));status=1 if flags else 2 if ts else 5 if istat else 0
 if not status and (not chirp or bm is None or bm<1 or bm>10**9 or tu is None or tu<10 or tu>100000):status=3
 dist=0
 if not status:
  speed=(42406400+606*raw+64)//128;dist=(speed*fm*tu+bm*1000)//(bm*2000)
  if dist>0xffffffff:dist=0;status=4
 refs.append(dict(id=len(refs),temp=raw,k=k,delta=delta,ts=ts,flags=flags,istat=istat,chirp=chirp,bw=bb,tc=tb,fm=fm,dist=dist,status=status))
for temp in [-20,0,20,25,40]:
 for hz in [58.3,100,145.8,380,875,1500]:
  for bw in [4000,8000,125.25]:
   for duration in [.02,.04,.00001,.1]:add(temp,hz,bw,duration)
for ts in [1,2,3]:add(ts=ts)
for flag in [1,2,4,8,16,32,128]:add(flags=flag)
for state in [1,2,3,4,5]:add(istat=state)
for kw in [dict(bw=0),dict(bw=-1),dict(duration=-1),dict(duration=0),dict(chirp=0),dict(bw_bits=0x7fc00000),dict(t_bits=0x7f800000),dict(bw=.001,duration=.1,hz=1500)]:add(**kw)
(O/'vectors.txt').write_text(''.join(f"{r['id']} {r['temp']} {r['k']} {r['delta']} {r['ts']} {r['flags']} {r['istat']} {r['chirp']} {r['bw']:08x} {r['tc']:08x}\n" for r in refs))
(O/'reference.json').write_text(json.dumps(refs,indent=2))
tb=r'''`timescale 1ns/1ps
module tb_measurement;
 reg c=0,rst=1,start=0;always #10 c=~c;
 reg [15:0] bin;reg signed [15:0] temp;reg signed [31:0] delta;
 reg [7:0] ts,flags,istat;reg [31:0] bw,tc;reg chirp;
 wire done;wire [31:0] fm,range_um;wire [7:0] status;
 MainRangeCalculator dut(.clk(c),.rst(rst),.i_start(start),.i_bin(bin),.i_fft_length(16'd1024),.i_flags(flags),.i_interp_status(istat),.i_temp_status(ts),.i_delta_q16(delta),.i_temp(temp),.i_bandwidth_fp(bw),.i_duration_fp(tc),.i_chirp(chirp),.o_done(done),.o_frequency_millihz(fm),.o_distance_um(range_um),.o_status(status));
 integer f,o,id,ti,ki,di,tsi,fi,ii,ci,rc,n;
 initial begin
  f=$fopen("vectors.txt","r");o=$fopen("actual.csv","w");$fwrite(o,"id,fm,dist,status,cycles\n");
  repeat(4)@(negedge c);rst=0;
  while(!$feof(f))begin
   rc=$fscanf(f,"%d %d %d %d %d %d %d %d %h %h\n",id,ti,ki,di,tsi,fi,ii,ci,bw,tc);if(rc!=10)$fatal(1,"Bad vector");
   temp=ti;bin=ki;delta=di;ts=tsi;flags=fi;istat=ii;chirp=ci;start=1;@(negedge c);start=0;n=0;
   // Inputs can change after acceptance: computation must use its snapshot.
   bw=0;tc=0;temp=0;
   while(!done&&n<300)begin @(negedge c);n++;end
   if(!done||$isunknown({fm,range_um,status}))$fatal(1,"Measurement timeout/unknown");
   $fwrite(o,"%0d,%0d,%0d,%0d,%0d\n",id,fm,range_um,status,n);@(negedge c);
  end
  $fclose(f);$fclose(o);$display("PASS MEASUREMENT ARITHMETIC");$finish;
 end
endmodule
module tb_temp_guard;
 reg c=0,rst=1,updated=0,valid=0,cap=0;always #3 c=~c;
 reg signed [15:0] temp=0;wire [15:0] snap;wire [7:0] status;
 MainTempSnapshot #(.MAX_AGE(8)) dut(.clk(c),.rst(rst),.i_updated(updated),.i_valid(valid),.i_capture(cap),.i_temp(temp),.o_temp(snap),.o_status(status));
 task capture(input integer expected);begin cap=1;@(negedge c);cap=0;if(status!==expected)$fatal(1,"Temp status wanted %0d got %0d",expected,status);@(negedge c);end endtask
 initial begin
  repeat(3)@(negedge c);rst=0;capture(1);
  temp=3200;updated=1;valid=1;capture(0);updated=0;if(snap!=3200)$fatal(1,"Temp snapshot");
  temp=4000;@(negedge c);if(snap!=3200)$fatal(1,"Frame temperature changed");
  repeat(9)@(negedge c);capture(2);
  updated=1;valid=0;capture(1);updated=0;
  temp=-2560;updated=1;valid=1;capture(0);updated=0;if($signed(snap)!=-2560)$fatal(1,"Negative temperature");
  temp=32767;updated=1;capture(3);updated=0;
  rst=1;@(negedge c);rst=0;capture(1);
  $display("PASS TEMP GUARD: missing, ACK, immutable, stale, NACK, negative, out-of-range, reset");$finish;
 end
endmodule
module tb_m4;
 reg c=0,fc=0,rst=1,start=0,txbusy=0;always #3 c=~c;always #10 fc=~fc;
 reg [31:0] bw=32'h457a0000,tc=32'h3ca3d70a;reg [15:0] temp=3200;reg [7:0] ts=0;
 wire [7:0] data;wire valid,busy,done;
 MainPeakReport #(.RANGE_REPORT(1)) dut(.clk(c),.rst(rst),.i_start(start),.i_tx_busy(txbusy),
 .i_seq(32'd1),.i_count(32'd672),.i_span(32'd3091968),.i_bin(15'd4),.i_power(41'd123456789),.i_min(-16'sd7000),.i_max(16'd7000),.i_flags(8'd0),
 .i_fft_length(16'd1024),.i_delta_q16(32'sd11110),.i_interp_status(8'd0),.i_calc_clk(fc),.i_calc_rst(rst),.i_temp(temp),.i_temp_status(ts),
 .i_bandwidth_fp(bw),.i_duration_fp(tc),.i_chirp(1'b1),.o_data(data),.o_valid(valid),.o_busy(busy),.o_done(done));
 integer o,n=0,hold_ticks=0,frame;
 always @(posedge c)begin
  if(hold_ticks>0)begin hold_ticks--;if(hold_ticks==0)txbusy<=0;end
  if(valid)begin if(txbusy)$fatal(1,"M4 handshake");$fwrite(o,"%c",data);n++;txbusy<=1;hold_ticks=4;end
 end
 initial begin
  o=$fopen("m4.txt","w");repeat(6)@(negedge fc);rst=0;
  for(frame=0;frame<3;frame++)begin
   @(negedge c);temp=frame==1 ? -2560:3200;ts=frame==2 ? 2:0;bw=32'h457a0000;tc=32'h3ca3d70a;start=1;n=0;
   @(negedge c);start=0;bw=0;temp=0;wait(done);@(negedge c);
   if(n!=110)$fatal(1,"M4 packet length %0d",n);
  end
  $fclose(o);$display("PASS M4 MAILBOX AND BACKPRESSURE");$finish;
 end
 initial begin #100000000;$fatal(1,"M4 timeout");end
endmodule
'''
(O/'tb.sv').write_text(tb)
files=[tree.file(n) for n in ['MainTempSnapshot.sv','MainRangeCalculator.sv','MainPeakReport.sv']]+[O/'tb.sv']
d='onerror {quit -code 1 -force}\nonbreak {quit -code 1 -force}\nvlib work\nvmap work work\nvlog -sv '+' '.join('{'+f.as_posix()+'}' for f in files)+'\n'
with (O/'simulation.log').open('w') as log:
 for index,top in enumerate(['tb_measurement','tb_temp_guard','tb_m4']):
  script=(d if index==0 else 'onerror {quit -code 1 -force}\nonbreak {quit -code 1 -force}\n')+f'vsim work.{top}\nrun -all\nquit -code 0 -force\n'
  (O/'run.do').write_text(script)
  subprocess.run([r'E:/Downloads/Questa/questa_fse/win64/vsim.exe','-c','-do','run.do'],cwd=O,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
log=(O/'simulation.log').read_text();assert '** Error' not in log and '** Fatal' not in log,log[-4000:]
import csv
actual=list(csv.DictReader((O/'actual.csv').open()));assert len(actual)==len(refs)
for r,e in zip(actual,refs):assert (int(r['fm']),int(r['dist']),int(r['status']))==(e['fm'],e['dist'],e['status']),(r,e)
lines=[s for s in (O/'m4.txt').read_text().splitlines() if s];assert len(lines)==3
for i,line in enumerate(lines):
 assert len(line)==108 and line.startswith('M4,');fields=line.split(',');assert len(fields)==18
 ck=0
 for b in line[:106].encode():ck^=b
 assert ck==int(line[106:],16)
 assert int(fields[12],16)==([3200,-2560,3200][i]&65535)
 assert int(fields[13],16)==(2 if i==2 else 0)
 assert int(fields[16],16)==(2 if i==2 else 0)
(O/'m4.txt').write_bytes(('\r\n'.join(lines)+'\r\n').encode())
result=dict(arithmetic_vectors=len(refs),arithmetic_exact_match=True,max_cycles=max(int(r['cycles']) for r in actual),temp_guard=True,m4_packets=3,m4_checksum=True,mailbox_snapshot=True,scope='Actual new FPGA arithmetic, frame temperature validity and M4 asynchronous mailbox. No physical sensor connected.')
(O/'checks.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
