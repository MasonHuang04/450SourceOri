`timescale 1ns/1ps
module tb_measurement;
 reg c=0,rst=1,start=0;always #10 c=~c;
 reg [15:0] bin;reg signed [15:0] temp;reg signed [31:0] delta;
 reg [7:0] ts,flags,istat;reg [31:0] bw,tc;reg chirp;
 wire done;wire [31:0] fm,range_um;wire [7:0] status;
 MainRangeCalculator dut(.clk(c),.rst(rst),.i_start(start),.i_bin(bin),.i_fft_length(16'd1024),.i_flags(flags),.i_interp_status(istat),.i_temp_status(ts),.i_delta_q16(delta),.i_temp(temp),.i_bandwidth_fp(bw),.i_duration_fp(tc),.i_chirp(chirp),.o_done(done),.o_frequency_millihz(fm),.o_distance_um(range_um),.o_status(status));
 integer f,o,id,ti,ki,di,tsi,fi,ii,ci,rc,n;
 initial begin
  f=$fopen("vectors.txt","r");o=$fopen("actual.csv","w");$fwrite(o,"id,fm,dist,status,cycles\n");
  repeat(4)@(negedge c);rst=0;
  while(!$feof(f))begin
   rc=$fscanf(f,"%d %d %d %d %d %d %d %d %h %h\n",id,ti,ki,di,tsi,fi,ii,ci,bw,tc);if(rc!=10)$fatal(1,"Bad vector");
   temp=ti;bin=ki;delta=di;ts=tsi;flags=fi;istat=ii;chirp=ci;start=1;@(negedge c);start=0;n=0;
   // Inputs can change after acceptance: computation must use its snapshot.
   bw=0;tc=0;temp=0;
   while(!done&&n<300)begin @(negedge c);n++;end
   if(!done||$isunknown({fm,range_um,status}))$fatal(1,"Measurement timeout/unknown");
   $fwrite(o,"%0d,%0d,%0d,%0d,%0d\n",id,fm,range_um,status,n);@(negedge c);
  end
  $fclose(f);$fclose(o);$display("PASS MEASUREMENT ARITHMETIC");$finish;
 end
endmodule
module tb_temp_guard;
 reg c=0,rst=1,updated=0,valid=0,cap=0;always #3 c=~c;
 reg signed [15:0] temp=0;wire [15:0] snap;wire [7:0] status;
 MainTempSnapshot #(.MAX_AGE(8)) dut(.clk(c),.rst(rst),.i_updated(updated),.i_valid(valid),.i_capture(cap),.i_temp(temp),.o_temp(snap),.o_status(status));
 task capture(input integer expected);begin cap=1;@(negedge c);cap=0;if(status!==expected)$fatal(1,"Temp status wanted %0d got %0d",expected,status);@(negedge c);end endtask
 initial begin
  repeat(3)@(negedge c);rst=0;capture(1);
  temp=3200;updated=1;valid=1;capture(0);updated=0;if(snap!=3200)$fatal(1,"Temp snapshot");
  temp=4000;@(negedge c);if(snap!=3200)$fatal(1,"Frame temperature changed");
  repeat(9)@(negedge c);capture(2);
  updated=1;valid=0;capture(1);updated=0;
  temp=-2560;updated=1;valid=1;capture(0);updated=0;if($signed(snap)!=-2560)$fatal(1,"Negative temperature");
  temp=32767;updated=1;capture(3);updated=0;
  rst=1;@(negedge c);rst=0;capture(1);
  $display("PASS TEMP GUARD: missing, ACK, immutable, stale, NACK, negative, out-of-range, reset");$finish;
 end
endmodule
module tb_m4;
 reg c=0,fc=0,rst=1,start=0,txbusy=0;always #3 c=~c;always #10 fc=~fc;
 reg [31:0] bw=32'h457a0000,tc=32'h3ca3d70a;reg [15:0] temp=3200;reg [7:0] ts=0;
 wire [7:0] data;wire valid,busy,done;
 MainPeakReport #(.RANGE_REPORT(1)) dut(.clk(c),.rst(rst),.i_start(start),.i_tx_busy(txbusy),
 .i_seq(32'd1),.i_count(32'd672),.i_span(32'd3091968),.i_bin(15'd4),.i_power(41'd123456789),.i_min(-16'sd7000),.i_max(16'd7000),.i_flags(8'd0),
 .i_fft_length(16'd1024),.i_delta_q16(32'sd11110),.i_interp_status(8'd0),.i_calc_clk(fc),.i_calc_rst(rst),.i_temp(temp),.i_temp_status(ts),
 .i_bandwidth_fp(bw),.i_duration_fp(tc),.i_chirp(1'b1),.o_data(data),.o_valid(valid),.o_busy(busy),.o_done(done));
 integer o,n=0,hold_ticks=0,frame;
 always @(posedge c)begin
  if(hold_ticks>0)begin hold_ticks--;if(hold_ticks==0)txbusy<=0;end
  if(valid)begin if(txbusy)$fatal(1,"M4 handshake");$fwrite(o,"%c",data);n++;txbusy<=1;hold_ticks=4;end
 end
 initial begin
  o=$fopen("m4.txt","w");repeat(6)@(negedge fc);rst=0;
  for(frame=0;frame<3;frame++)begin
   @(negedge c);temp=frame==1 ? -2560:3200;ts=frame==2 ? 2:0;bw=32'h457a0000;tc=32'h3ca3d70a;start=1;n=0;
   @(negedge c);start=0;bw=0;temp=0;wait(done);@(negedge c);
   if(n!=110)$fatal(1,"M4 packet length %0d",n);
  end
  $fclose(o);$display("PASS M4 MAILBOX AND BACKPRESSURE");$finish;
 end
 initial begin #100000000;$fatal(1,"M4 timeout");end
endmodule
