from pathlib import Path
import sys,subprocess,json
A=Path(__file__).resolve().parent;P=A/'project';O=A/'interface_tests';O.mkdir(exist_ok=True)
sys.path.insert(0,str(P/'02_RTL/V0/Simulation'))
from source_units import SourceTree
tree=SourceTree(P/'02_RTL/V0/SourceCode',O)
tb=r'''`timescale 1ns/1ps
module tb_temp_i2c;
 reg c=0,rst=1;always #3.030303 c=~c;
 wire scl,valid,updated;tri1 sda;reg slave_low=0;reg ack=1;reg [15:0] word_value=16'h0c80;wire [15:0] temp;
 assign sda=slave_low?1'b0:1'bz;
 MainTMP117Controller dut(.iClk(c),.iRst(rst),.iAddr(8'h48),.oDataValid(valid),.oUpdated(updated),.oTempData(temp),.oTmp_SCL(scl),.ioTmp_SDA(sda));
 integer bit_index=0,k;bit active=0;reg [7:0] address=0;realtime last_rise=-1e6,last_fall=-1e6,last_data=-1e6;
 always @(sda)last_data=$realtime;
 always @(negedge sda)if(scl&&!active)begin active=1;bit_index=0;address=0;end
 always @(posedge sda)if(scl&&active&&bit_index>=27)begin active=0;slave_low=0;end
 always @(negedge scl)begin
 if(active&&$realtime-last_rise<600)$fatal(1,"TMP117 SCL high <600ns");last_fall=$realtime;
 if(active)begin
  if(bit_index==8)slave_low=ack;
  else if(ack&&bit_index>=9&&bit_index<=16)slave_low=!word_value[24-bit_index];
  else if(ack&&bit_index>=18&&bit_index<=25)slave_low=!word_value[25-bit_index];
  else slave_low=0;
 end end
 always @(posedge scl)begin
 last_rise=$realtime;if(active)begin
  if($realtime-last_fall<1300)$fatal(1,"TMP117 SCL low <1300ns");
  if($realtime-last_data<100)$fatal(1,"TMP117 data setup <100ns");
  if(bit_index==26&&sda!==1)$fatal(1,"Master must NACK last byte");
  if(bit_index<8)begin address={address[6:0],sda};if(bit_index==7&&address!=8'h91)$fatal(1,"TMP117 address/RW");end
  bit_index++;
 end end
 initial begin
  repeat(10)@(negedge c);rst=0;
  for(k=0;k<3;k++)begin
   ack=k!=2;word_value=k==1 ? 16'hf600:16'h0c80;
   wait(updated);#1;
   if(valid!==ack)$fatal(1,"I2C ACK validity");
   if(ack&&temp!==word_value)$fatal(1,"I2C temperature data %h wanted %h",temp,word_value);
   @(posedge c);#1;if(updated)$fatal(1,"Update must be one clock");
  end
  $display("PASS TMP117 I2C: address, positive/negative Q7, ACK/NACK and update pulse");$finish;
 end
 initial begin #5000000;$fatal(1,"I2C timeout");end
endmodule
module tb_m4_uart;
 reg c=0,fc=0,rst=1,start=0;always #3.030303 c=~c;always #10 fc=~fc;
 wire [7:0] data;wire valid,busy,done,txbusy,uart;wire [7:0] unused_rx;wire unused_rv;
 MainPeakReport #(.RANGE_REPORT(1)) dut(.clk(c),.rst(rst),.i_start(start),.i_tx_busy(txbusy),
 .i_seq(32'd1),.i_count(32'd672),.i_span(32'd3091968),.i_bin(15'd4),.i_power(41'd123456789),.i_min(-16'sd7000),.i_max(16'd7000),.i_flags(8'd0),
 .i_fft_length(16'd1024),.i_delta_q16(32'sd11110),.i_interp_status(8'd0),.i_calc_clk(fc),.i_calc_rst(rst),.i_temp(16'd3200),.i_temp_status(8'd0),
 .i_bandwidth_fp(32'h457a0000),.i_duration_fp(32'h3ca3d70a),.i_chirp(1'b1),.o_data(data),.o_valid(valid),.o_busy(busy),.o_done(done));
 UARTController line(.iClk(c),.iRst(rst),.iRx(1'b1),.oTx(uart),.oRxDataValid(unused_rv),.oRxData(unused_rx),.oTxBusy(txbusy),.iTxDataValid(valid),.iTxData(data));
 integer o,n=0,b;reg [7:0] ch;
 initial begin o=$fopen("uart_m4.txt","w");repeat(20)@(negedge c);rst=0;start=1;@(negedge c);start=0;wait(done);#1000;
  if(n!=110)$fatal(1,"UART byte count %0d",n);$fclose(o);$display("PASS M4 PHYSICAL UART: 110 bytes at 2 Mbaud");$finish;end
 always @(negedge uart)if(!rst)begin
  #250;if(uart!==0)$fatal(1,"UART start");
  for(b=0;b<8;b++)begin #500;ch[b]=uart;end
  #500;if(uart!==1)$fatal(1,"UART stop");$fwrite(o,"%c",ch);n++;
 end
 initial begin #2000000;$fatal(1,"UART timeout");end
endmodule
'''
(O/'tb.sv').write_text(tb)
vhd=[tree.file(n) for n in ['SysLib.vhd','UARTController.vhd','MainTMP117Controller.vhd']]
sv=[tree.file(n) for n in ['MainRangeCalculator.sv','MainPeakReport.sv']]+[O/'tb.sv']
compile='onerror {quit -code 1 -force}\nonbreak {quit -code 1 -force}\nvlib work\nvmap work work\n'
for p in vhd:compile+='vcom -2008 {'+p.as_posix()+'}\n'
compile+='vlog -sv '+' '.join('{'+p.as_posix()+'}' for p in sv)+'\n'
with (O/'simulation.log').open('w') as log:
 for index,top in enumerate(['tb_temp_i2c','tb_m4_uart']):
  d=(compile if index==0 else 'onerror {quit -code 1 -force}\nonbreak {quit -code 1 -force}\n')+f'vsim work.{top}\nrun -all\nquit -code 0 -force\n'
  (O/'run.do').write_text(d)
  subprocess.run([r'E:/Downloads/Questa/questa_fse/win64/vsim.exe','-c','-do','run.do'],cwd=O,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
log=(O/'simulation.log').read_text();assert '** Error' not in log and '** Fatal' not in log
lines=[s for s in (O/'uart_m4.txt').read_text().splitlines() if s];assert len(lines)==1
assert len(lines[0])==108 and lines[0].startswith('M4,')
ck=0
for b in lines[0][:106].encode():ck^=b
assert ck==int(lines[0][106:],16)
(O/'uart_m4.txt').write_bytes((lines[0]+'\r\n').encode())
(O/'checks.json').write_text(json.dumps(dict(tmp117_i2c_model=True,ack_nack=True,signed_temperature=True,update_pulse=True,i2c_rate_khz=165000/128/4,i2c_pin_timing=True,last_byte_nack=True,physical_uart_2mbaud=True,m4_bytes=110,checksum=True,hardware_sensor_tested=False),indent=2))
print('PASS: production TMP117 controller with I2C slave model; M4 through actual UART bit transmitter')
