onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vsim work.tb_m4_uart
run -all
quit -code 0 -force
