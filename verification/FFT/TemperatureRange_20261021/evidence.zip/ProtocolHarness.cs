using System;
using System.IO;
using System.Text;
using System.Globalization;
using UsMimoTestBench;
class ProtocolHarness {
 static void Check(bool b,string text){if(!b)throw new Exception(text);}
 static byte[] HexFile(string p){string[] words=File.ReadAllText(p).Split((char[])null,StringSplitOptions.RemoveEmptyEntries);byte[] b=new byte[words.Length];for(int i=0;i<b.Length;i++)b[i]=byte.Parse(words[i],NumberStyles.HexNumber);return b;}
 static void Main(string[] args){
  string[] lines=File.ReadAllLines(args[0]);Check(lines.Length==3,"Three actual RTL mailbox records");
  for(int i=0;i<3;i++){
   MainReport r=MainReport.Parse(lines[i]+"\r\n");
   Check(r.HasMeasurement&&r.TemperatureRawQ7==(i==1?-2560:3200),"Actual FPGA signed temperature");
   Check(r.TemperatureStatus==(i==2?2:0)&&r.RangeValid==(i!=2),"Actual FPGA validity");
   if(r.RangeValid)Check(Math.Abs(r.DistanceMm-r.SoundSpeed*r.Frequency*.02/8000*1000)<=.001,"Actual FPGA distance and units");
  }
  MainReport uart=MainReport.Parse(File.ReadAllText(args[1]));Check(uart.RangeValid&&uart.TemperatureC==25,"Physical UART M4 in production C# parser");
  byte[] bytes=HexFile(args[2]);MainStreamParser p=new MainStreamParser();int raws=0,peaks=0;
  p.Raw=f=>{raws++;Check(f.DataLen==5442,"Full actual Main waveform");};
  p.Peak=r=>{peaks++;Check(r.HasMeasurement&&r.TemperatureC==25,"Main top temperature snapshot");Check(r.Status=="BAD_CADENCE"&&!r.RangeValid,"Compressed-idle fixture remains flagged");};
  for(int i=0;i<bytes.Length;){int n=Math.Min(1+i%89,bytes.Length-i);byte[] q=new byte[n];Array.Copy(bytes,i,q,0,n);p.Feed(q,n);i+=n;}
  Check(raws==1&&peaks==1&&p.Invalid==0&&p.BufferedBytes==0,"Full mixed raw/M4 stream fragmented parse");
  Console.WriteLine("PASS production C# parser: actual M4 arithmetic packets, real UART bits, full 5442-word Main frame, fragmented reads and validity");
 }
}
