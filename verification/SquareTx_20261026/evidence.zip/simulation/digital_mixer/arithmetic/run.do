onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vlog -sv {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/multifpga_square_fix_20261026/project/02_RTL/V0/Simulation/FFT/results/main/digital_mixer/arithmetic/units/ScopeAdc27m5.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/multifpga_square_fix_20261026/project/02_RTL/V0/Simulation/FFT/results/main/digital_mixer/arithmetic/units/MainAdcBridge.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/multifpga_square_fix_20261026/project/02_RTL/V0/Simulation/FFT/results/main/digital_mixer/arithmetic/units/MainReferenceDelay.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/multifpga_square_fix_20261026/project/02_RTL/V0/Simulation/FFT/results/main/digital_mixer/arithmetic/units/MainDigitalMixer.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/multifpga_square_fix_20261026/project/02_RTL/V0/Simulation/FFT/tb_digital_mixer.sv}
vsim -t 1ps -L altera_mf work.tb_mixer_arithmetic
run -all
quit -code 0 -force
