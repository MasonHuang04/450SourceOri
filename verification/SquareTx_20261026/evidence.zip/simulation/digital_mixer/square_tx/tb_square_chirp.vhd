library ieee;
use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.textio.all;use std.env.all;
entity tb_square_chirp is end;
architecture test of tb_square_chirp is
 signal clk:std_logic:='0';signal rst:std_logic:='1';signal done:boolean:=false;
 signal idx:std_logic_vector(31 downto 0):=(others=>'0');
 signal amp:std_logic_vector(31 downto 0):=x"3e800000";
 signal square_wave,sine_wave:integer range 0 to 16383;
begin
 clk<=not clk after 3.030303 ns when not done else '0';
 dut:entity work.ChirpWaveGen(Beh) port map(iClk=>clk,iRst=>rst,iSQWaveEn=>'1',iDIdx=>idx,
 iF0=>x"47147000",iK=>x"48435000",iA=>amp,iDT=>x"31d03da8",
 oWaveform=>square_wave,oSineWaveform=>sine_wave);
 process
  file f:text open write_mode is "square_sine.csv";variable l:line;variable n,tick:integer;
 begin
  for c in 0 to 4 loop
   rst<='1';idx<=(others=>'0');
   case c is when 0=>amp<=x"3e800000";when 1=>amp<=x"3e000000";
    when 2=>amp<=x"3f000000";when 3=>amp<=x"3f800000";when others=>amp<=x"00000000";end case;
   for j in 1 to 30 loop wait until falling_edge(clk);end loop;rst<='0';
   for j in 1 to 300 loop wait until falling_edge(clk);end loop;
   if c=0 then n:=5001;else n:=501;end if;
   for j in 0 to n+140 loop
    if j<n then tick:=j*660;else tick:=(n-1)*660;end if;
    idx<=std_logic_vector(to_unsigned(tick,32));wait until rising_edge(clk);wait for 1 ps;
    write(l,c);write(l,string'(","));write(l,j);write(l,string'(","));write(l,tick);
    write(l,string'(","));write(l,square_wave);write(l,string'(","));write(l,sine_wave);writeline(f,l);
    wait until falling_edge(clk);
   end loop;
  end loop;
  report "PASS SQUARE AND SINE CHIRP EXPORT";done<=true;wait;
 end process;
end;
