
`timescale 1ns/1ps
module MainPLL(input refclk,rst,output reg outclk_0=0,output reg locked=0);
 always #3.030303 outclk_0=~outclk_0;initial begin #200;locked=1;end
endmodule
module FPFMult(input clk,areset,input [31:0] a,b,output reg [31:0] q);
 always @(a,b,areset) q=areset ? 0 : $shortrealtobits($bitstoshortreal(a)*$bitstoshortreal(b));
endmodule
module FPFFP32ToInt32(input clk,areset,input [31:0] a,output reg [31:0] q);
 always @(a,areset) q=areset ? 0 : $rtoi($bitstoshortreal(a));
endmodule
module FPFInt32ToFP32(input clk,areset,input [31:0] a,output reg [31:0] q);
 always @(a,areset) q=areset ? 0 : $shortrealtobits(shortreal'($signed(a)));
endmodule
module UARTController(input iClk,iRst,iRx,output oTx,output oRxDataValid,output [7:0] oRxData,
 output reg oTxBusy=0,input iTxDataValid,input [7:0] iTxData);
 assign oTx=1;assign oRxDataValid=0;assign oRxData=0;integer delay_count=0;
 always @(posedge iClk)begin
  if(iRst)begin oTxBusy<=0;delay_count<=0;end
  else begin
   if(delay_count>0)begin delay_count<=delay_count-1;if(delay_count==1)oTxBusy<=0;end
   if(iTxDataValid)begin
    if(oTxBusy)$fatal(1,"UART byte handshake collision");oTxBusy<=1;delay_count<=8;
   end
  end
 end
endmodule

`timescale 1ns/1ps
module tb_main_top;
 integer fft_clock_edges=0;
 always @(posedge dut.cfftclk)fft_clock_edges++;
 initial begin #1000;if($isunknown(dut.cfftclk)||fft_clock_edges!=50)$fatal(1,"Main FFT divider must produce 50 MHz");end
 reg clk100=0;always #5 clk100=~clk100;
 reg sdo=0,drdy=1;wire uart,ad_clk,sclk,cs,sdi,start,resetn;tri1 sda;
 UsMimoTestBench #(.BOOT_CYCLES(50000),.AUTO_TRIGGER_DEFAULT(3)) dut(
 .iMAIN_CLK(clk100),.iUART_RXD(1'b1),.iUART_RTS(1'b0),.iAD_SDO(sdo),.iAD_DRDY(drdy),.ioTMP_SDA(sda),
 .oUART_TXD(uart),.oAD_CLK(ad_clk),.oAD_SCLK(sclk),.oAD_CS(cs),.oAD_SDI(sdi),.oAD_START(start),.oAD_RST(resetn));
 integer case_no=0,conversion=0,clk_ticks=0,frame_start_index=0;
 integer ready_code=0,read_code=0,read_index=0,read_bits=0,fall_bits=0,init_count=0;
 reg [15:0] command_word=0;
 bit initialized=0,active=0;
 realtime last_fall=-1e6,last_sdi=-1e6,cs_fall=-1e6,cs_rise=-1e6,reset_release=0;
 realtime adc_edge=-1e6,spi_edge=-1e6,adc_rise=-1e6,start_edge=-1e6,reset_low=-1e6;
 integer reset_clocks=0,spi_frames=0;
 function automatic [15:0] init_word(input integer n);
  case(n)0:init_word=16'h0000;1:init_word=16'h8500;2:init_word=16'h8687;
  3:init_word=16'h870c;4:init_word=16'h8880;5:init_word=16'h8908;default:init_word=0;endcase
 endfunction
 always @(ad_clk)begin
  if($realtime>1000&&$realtime-adc_edge<13.199)$fatal(1,"ADC CLK pulse too short");
  adc_edge=$realtime;
 end
 always @(sclk)begin
  if($realtime>1000&&$realtime-spi_edge<13.199)$fatal(1,"SCLK pulse too short");
  spi_edge=$realtime;
 end
 always @(start)begin
  if(resetn&&$realtime-adc_rise<8.999)$fatal(1,"START hold <9ns");
  start_edge=$realtime;
 end
 always @(posedge ad_clk)begin
  if(resetn&&$realtime-start_edge<8.999)$fatal(1,"START setup <9ns");
  adc_rise=$realtime;
 end
 always @(negedge resetn)reset_low=$realtime;
 always @(posedge resetn)begin
  if($realtime-reset_low<145.45)$fatal(1,"RESET low shorter than 4 ADC clocks");
  reset_release=$realtime;reset_clocks=0;
 end
 always @(posedge ad_clk)if(resetn)reset_clocks++;
 real f,phase,value_real,rf_time,u;
 integer sys_ticks=0,tx_epoch_tick=0;
 always @(posedge dut.cclkh)sys_ticks++;
 always @(posedge dut.ctx_busy)tx_epoch_tick=sys_ticks;
 always @(negedge ad_clk)begin
  if(!resetn||!start)begin clk_ticks=0;conversion=0;drdy=1;end
  else begin
   clk_ticks++;
   if(case_no==4)drdy=1;
   else if(clk_ticks>=96&&((clk_ticks-96)%24)==0)begin
    // Same master-clock timebase as TX: avoid 1 ps simulator rounding
    // turning #3.030303 ns into a 100 ppm TX/RX oscillator mismatch.
    rf_time=real'(sys_ticks-tx_epoch_tick)/165000000.0;u=rf_time-1.0/346.45;
    value_real=111;
    if(u>=0&&u<0.020)value_real=(24000*4.0/3.141592653589793)*$cos(6.283185307179586*(38000*u+100000*u*u))+111;
    ready_code=$rtoi(value_real);conversion++;drdy=0;
   end else if(clk_ticks>=98&&((clk_ticks-98)%24)==0)drdy=1;
  end
 end
 always @(sdi)begin
  if(active&&$realtime-last_fall<5.999)$fatal(1,"SDI hold <6ns");
  last_sdi=$realtime;
 end
 always @(negedge cs)begin
  if(resetn)begin
   if(reset_clocks<10000)$fatal(1,"ADC reset recovery <10000 clocks");
   if($realtime-cs_rise<19.999)$fatal(1,"CS high <20ns");
   cs_fall=$realtime;active=1;read_bits=0;fall_bits=0;command_word=0;
   read_code=ready_code;read_index=conversion-1;spi_frames++;
  end
 end
 always @(posedge sclk)if(active)begin
  if(read_bits==0&&$realtime-cs_fall<9.999)$fatal(1,"CS setup <10ns");
  if(initialized)begin
   if(read_bits<16)sdo<=#23 ((read_code>>(15-read_bits))&1);else sdo<=#23 0;
  end
  read_bits++;
 end
 always @(negedge sclk)if(active)begin
  last_fall=$realtime;
  if($realtime-last_sdi<3.999)$fatal(1,"SDI setup <4ns");
  command_word={command_word[14:0],sdi};fall_bits++;
 end
 always @(posedge cs)if(active)begin
  if($realtime-last_fall<9.999)$fatal(1,"CS hold <10ns");
  active=0;cs_rise=$realtime;
  if(!initialized)begin
   if(fall_bits!=16||command_word!==init_word(init_count))$fatal(1,"ADC init mismatch frame=%0d bits=%0d word=%h",init_count,fall_bits,command_word);
   init_count++;if(init_count==6)initialized=1;
  end else if(read_bits!=16)$fatal(1,"ADC read length=%0d",read_bits);
 end
 always @(negedge ad_clk)if(dut.urx.uad.valid)begin
  if($signed(dut.urx.uad.sample)!==read_code)$fatal(1,"ADC decode got=%0d expected=%0d",$signed(dut.urx.uad.sample),read_code);
 end

 integer raw_count=0,fft_count=0,byte_count=0;integer rf,ff,bf;integer raw_expected[0:131071];
 integer full_count=0,raw_skip=0,last_full_tick=0,tick=0,cap_begin=0,cap_end=0;
 reg cap_last=0;reg [15:0] last_sample=0;
 initial begin
  rf=$fopen("raw_words.csv","w");ff=$fopen("fft_capture.csv","w");bf=$fopen("stream.hex","w");
  $fwrite(rf,"index,code
");$fwrite(ff,"index,code
");
 end
 always @(posedge dut.cclkh)if(!dut.crst)begin
  tick++;
  if(dut.ccaptureactive&&!cap_last)cap_begin=tick;
  if(!dut.ccaptureactive&&cap_last)begin
   cap_end=tick;if(cap_end-cap_begin!=3135001)$fatal(1,"RX19ms duration incorrect: %0d",cap_end-cap_begin);
   $display("PASS MAIN capture window ticks=%0d full_words=%0d raw_words=%0d",cap_end-cap_begin,full_count,raw_count);
  end
  cap_last=dut.ccaptureactive;
  if(dut.cfullvalid)begin
   if(full_count>0&&tick-last_full_tick!=144)$fatal(1,"Full ADC cadence");last_full_tick=tick;
   if($signed(dut.cfullvalue)!==read_code)$fatal(1,"ADC stable-word CDC mismatch");
   full_count++;raw_skip++;if(raw_skip==4)begin raw_skip=0;last_sample=dut.cfullvalue^16'h8000;end
  end
  if(dut.crx_newdata)begin
   if(dut.crx_value!==last_sample)$fatal(1,"Raw /4 value mismatch");
   raw_expected[raw_count]=dut.crx_value;$fwrite(rf,"%0d,%0d
",raw_count,dut.crx_value);raw_count++;
  end
  if(dut.ufft.ram_we)begin $fwrite(ff,"%0d,%0d
",fft_count,$signed(dut.ufft.cs));fft_count++;end
  if(dut.cuart_txdatavalid)begin
   if(dut.cuart_txbusy)$fatal(1,"Top mux transmitted busy");
   $fwrite(bf,"%02x
",dut.cuart_txdata);byte_count++;
  end
  if(dut.cfftsenddone)begin
   if(raw_count!=full_count/4||dut.crx_datacnt!=raw_count)$fatal(1,"Raw count mismatch");
   if(dut.cfftcount!=672||fft_count!=672||dut.creportflags!=0||dut.cfftbin!=17||dut.cfftspan!=3091968)$fatal(1,"RF top FFT count/peak/span/flags");
   if(dut.crx_muxsel[2]!==0)$fatal(1,"Raw RF must bypass analog IF LPF");
   if(byte_count!=raw_count*2+174)$fatal(1,"Raw+FFT record length mismatch");
   $display("PASS DIGITAL MAIN RF TOP: 19ms real cadence, raw RF ADC SPI/reference pairing/mixer/CIC/FFT/full raw packet/M4; raw=%0d full=%0d bytes=%0d peak=%0d power=%0d",raw_count,full_count,byte_count,dut.cfftbin,dut.cfftpower);
   $fclose(rf);$fclose(ff);$fclose(bf);#100;$finish;
  end
 end
 initial begin #300000000;$fatal(1,"Global main top timeout");end
endmodule

