onerror {quit -code 1 -force}
onbreak {resume}
vlib work
vmap work work
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/SysLib.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/UARTController.vhd}
vcom -2008 {E:/Document_HH/Course/26FA/450code/15_UsMimoTestBench/02_RTL/V0/SourceCode/RxDepack.vhd}
vcom -2008 {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/sw_main_ui_20261017/tb_settings_uart.vhd}
vsim -t 1ps work.tb_settings_uart
set NumericStdNoWarnings 1
set StdArithNoWarnings 1
run 1 ms
quit -code 0 -force
