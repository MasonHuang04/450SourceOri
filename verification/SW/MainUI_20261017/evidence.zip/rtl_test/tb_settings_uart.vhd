library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_textio.all;
use std.textio.all;
use work.SysLib.all;

entity tb_settings_uart is end;
architecture test of tb_settings_uart is
 type bytes144 is array(0 to 143) of std_logic_vector(7 downto 0);
 impure function load_commands return bytes144 is
  file f:text open read_mode is "commands.hex";
  variable l:line; variable a:bytes144;
 begin
  for i in a'range loop readline(f,l);hread(l,a(i));end loop;
  return a;
 end;
 constant command:bytes144:=load_commands;
 signal clk:std_logic:='0'; signal rst:std_logic:='1';signal serial_rx:std_logic:='1';
 signal valid,trig,pack_valid:std_logic; signal data:std_logic_vector(7 downto 0);
 signal pack:Bytex56;signal pack_count,trigger_count,byte_count:integer:=0;
begin
 clk<=not clk after 3030 ps;
 uart:entity work.UARTController port map(iClk=>clk,iRst=>rst,iRx=>serial_rx,oTx=>open,
   oRxDataValid=>valid,oRxData=>data,oTxBusy=>open,iTxDataValid=>'0',iTxData=>(others=>'0'));
 decode:entity work.RxDepack port map(iClk=>clk,iRst=>rst,iRxDataValid=>valid,iRxData=>data,
   oTrigger=>trig,oRxPackValid=>pack_valid,oRxPack=>pack);
 process(clk)
 begin
  if rising_edge(clk) and rst='0' then
   if valid='1' then
    assert byte_count<144 report "Unexpected UART byte" severity failure;
    assert data=command(byte_count) report "UART byte differs from C# output" severity failure;
    byte_count<=byte_count+1;
   end if;
   if pack_valid='1' then
    assert pack_count<2 report "Extra settings packet" severity failure;
    for i in 0 to 55 loop
     assert pack(i)=command(pack_count*72+4+i) report "Decoded field byte mismatch" severity failure;
    end loop;
    assert pack(0)=x"00" and pack(4)=x"00" and pack(7)=x"0E" and pack(24)=x"00" report "Main TX mode changed" severity failure;
    assert (pack(39)&pack(38)&pack(37)&pack(36))=x"3E800000" report "RX duration changed" severity failure;
    assert (pack(43)&pack(42)&pack(41)&pack(40))=x"3A83126F" report "RX delay changed" severity failure;
    assert pack(44)=x"03" and pack(45)=x"00" and pack(46)=x"10" and pack(47)=x"04" report "RX format/mux changed" severity failure;
    if pack_count=0 then
     assert (pack(11)&pack(10)&pack(9)&pack(8))=x"471C4000" report "Default Fc not 40k" severity failure;
     assert (pack(15)&pack(14)&pack(13)&pack(12))=x"457A0000" report "Default BW not 4k" severity failure;
     assert (pack(19)&pack(18)&pack(17)&pack(16))=x"3CA3D70A" report "Default duration not 20ms" severity failure;
     assert (pack(23)&pack(22)&pack(21)&pack(20))=x"3E800000" report "Default amplitude not .25" severity failure;
    else
     assert (pack(11)&pack(10)&pack(9)&pack(8))=x"48435000" report "Custom Fc not 200k" severity failure;
     assert (pack(15)&pack(14)&pack(13)&pack(12))=x"469C4000" report "Custom BW not 20k" severity failure;
     assert (pack(19)&pack(18)&pack(17)&pack(16))=x"3DA3D70A" report "Custom duration not 80ms" severity failure;
     assert (pack(23)&pack(22)&pack(21)&pack(20))=x"3F000000" report "Custom amplitude not .5" severity failure;
    end if;
    pack_count<=pack_count+1;
   end if;
   if trig='1' then
    assert pack_count=trigger_count+1 report "Trigger preceded settings or duplicated" severity failure;
    trigger_count<=trigger_count+1;
   end if;
  end if;
 end process;
 process
 begin
  wait for 2 us;rst<='0';wait for 3 us;
  for i in command'range loop
   serial_rx<='0';wait for 500 ns;
   for j in 0 to 7 loop serial_rx<=command(i)(j);wait for 500 ns;end loop;
   serial_rx<='1';wait for 500 ns;
  end loop;
  wait for 10 us;
  assert byte_count=144 and pack_count=2 and trigger_count=2 report "Settings/trigger totals incorrect" severity failure;
  report "PASS SW SETTINGS THROUGH REAL UART RTL: 144 bytes, two settings, two triggers, all TX fields and fixed RX checked";
  std.env.stop;wait;
 end process;
end;
