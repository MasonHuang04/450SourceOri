`timescale 1ns/1ps
module tb_mixer_frames;
 localparam integer WORDS=21770;
`ifdef MIX_REAL_CADENCE
 localparam integer TICKS=144,FIRST_CASE=16,LAST_CASE=16;
`else
 localparam integer TICKS=8,FIRST_CASE=0,LAST_CASE=5;
`endif
 reg clk=0,fftclk=0,rst=1,start=0,active=0,valid=0;
 always #3.030303 clk=~clk;always #10 fftclk=~fftclk;
 reg signed [15:0] rx=0,reference=0;
 wire mv,mc;wire signed [15:0] mixed;
 MainDigitalMixer mixer(.clk(clk),.rst(rst),.i_frame_start(start),.i_valid(valid),
  .i_rx(rx),.i_reference(reference),.o_valid(mv),.o_sample(mixed),.o_clipped(mc));
 wire done;wire [31:0] seq,count,span,delta;wire [14:0] bin;
 wire [40:0] power;wire [15:0] mn,mx;wire [7:0] flags,status;
 MainFftProcessor #(.SAMPLE_TICKS(32*TICKS),.MIN_BIN(1),.MAX_BIN(57)) dut(
  .sys_clk(clk),.fft_clk(fftclk),.sys_rst(rst),.fft_rst(rst),.i_start(start),
  .i_capture_active(active),.i_raw_valid(mv),.i_raw_sample(mixed),
  .o_done(done),.o_seq(seq),.o_count(count),.o_span(span),.o_bin(bin),.o_power(power),
  .o_min(mn),.o_max(mx),.o_flags(flags),.o_delta_q16(delta),.o_interp_status(status));
 reg [15:0] rx_words[0:WORDS-1],reference_words[0:WORDS-1],expected_products[0:WORDS-1];
 integer cap_file,spec_file,meta_file,case_no=0,products=0;
 always @(posedge clk)if(!rst)begin
  if(mv)begin
   if(mixed!==expected_products[products])$fatal(1,"Frame %0d product %0d mismatch",case_no,products);
   products++;
  end
  if(dut.ram_we)$fwrite(cap_file,"%0d,%0d,%0d\n",case_no,dut.cap_count,$signed(dut.cs));
 end
 always @(posedge fftclk)if(!rst&&dut.power_valid)
  $fwrite(spec_file,"%0d,%0d,%0d,%0d,%0d\n",case_no,dut.power_bin,$signed(dut.power_re),$signed(dut.power_im),dut.power_value);
 initial begin
  cap_file=$fopen("capture.csv","w");spec_file=$fopen("spectrum.csv","w");meta_file=$fopen("metadata.csv","w");
  $fwrite(cap_file,"case,index,code\n");$fwrite(spec_file,"case,bin,real,imag,power\n");
  $fwrite(meta_file,"case,count,span,bin,power,delta,status,flags\n");
  repeat(20)@(negedge clk);rst=0;repeat(20)@(negedge clk);
  for(case_no=FIRST_CASE;case_no<=LAST_CASE;case_no++)begin
   $readmemh($sformatf("rx_%0d.mem",case_no),rx_words);
   $readmemh($sformatf("ref_%0d.mem",case_no),reference_words);
   $readmemh($sformatf("product_%0d.mem",case_no),expected_products);
   products=0;start=1;active=1;repeat(3)@(negedge clk);start=0;repeat(3)@(negedge clk);
   for(integer n=0;n<WORDS;n++)begin
    rx=rx_words[n];reference=reference_words[n];valid=1;
    @(negedge clk);valid=0;repeat(TICKS-1)@(negedge clk);
   end
   repeat(12)@(negedge clk);active=0;wait(done);repeat(5)@(negedge clk);
   if(products!=WORDS||count!=672||span!=671*32*TICKS||((flags!=0)&&(flags!=16))||((flags==0)&&(status!=0))||((flags==16)&&(status!=1))||mc)
    $fatal(1,"Frame %0d count/span/flags/status: products=%0d count=%0d span=%0d flags=%h status=%h",case_no,products,count,span,flags,status);
   $fwrite(meta_file,"%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d\n",case_no,count,span,bin,power,$signed(delta),status,flags);
   $display("PASS MIXER FRAME case=%0d bin=%0d delta=%0d",case_no,bin,$signed(delta));
   repeat(50)@(negedge clk);
  end
  $fclose(cap_file);$fclose(spec_file);$fclose(meta_file);
  $display("PASS ROUTE AUDIT: complete RF words -> actual mixer/CIC/Kaiser/FFT/power/interpolation; ticks=%0d",TICKS);
  $finish;
 end
 initial begin #200000000;$fatal(1,"Digital mixer frame timeout");end
endmodule

