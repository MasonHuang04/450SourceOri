onerror {quit -code 1 -force}
onbreak {quit -code 1 -force}
vlib work
vmap work work
vlog -sv +define+FFT_USE_INTEL_RAM {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/mixer_route_audit_20261028/run/units/MainDigitalMixer.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/mixer_route_audit_20261028/run/units/MainFftProcessor.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/mixer_route_audit_20261028/run/units/MainCicDecimator.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/mixer_route_audit_20261028/run/units/MainFrameRam.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/mixer_route_audit_20261028/run/units/kaiser4_rfft.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/mixer_route_audit_20261028/run/units/fft_tdp_store.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/mixer_route_audit_20261028/run/units/fft_power_peak.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/mixer_route_audit_20261028/run/units/main_peak_interpolator.sv} {C:/Users/admin/.codex/visualizations/2026/10/09/01a120ee-8376-76a1-b902-05acd791be04/mixer_route_audit_20261028/run/tb_route.sv}
vsim -t 1ps -L altera_mf work.tb_mixer_frames
run -all
quit -code 0 -force
