// Three-point log-power parabola, computed entirely in the FFT clock domain.
// log(power)=2*log(amplitude), so the ratio equals the MATLAB log-amplitude
// formula. Output is signed Q16 bin offset, clamped to [-0.5,+0.5].
// Status: 0 valid; 1 invalid frame; 2 missing/mismatched neighbors;
//         3 zero power; 4 not a local maximum; 5 non-concave logarithms.
// A reused 25x25 multiplier computes log2 to 16 fraction bits. A restoring
// divider avoids a large combinational divide. No logarithm IP/ROM required.
module main_peak_interpolator #(
 parameter integer MIN_BIN=6,MAX_BIN=114
)(input logic clk,rst,
 input logic i_valid,i_sop,input logic [14:0] i_bin,input logic [40:0] i_power,
 input logic i_peak_valid,i_enable,input logic [14:0] i_peak_bin,input logic [40:0] i_peak_power,
 output logic o_done,output logic signed [31:0] o_delta_q16,output logic [7:0] o_status);
 logic seen,prev_valid,left_valid,right_valid;
 logic [14:0] best_bin,prev_bin;
 logic [40:0] best_power,prev_power,left_power,right_power;
 wire eligible=(i_bin>=MIN_BIN)&&(i_bin<=MAX_BIN);
 wire better=eligible&&(!seen||i_power>best_power||(i_power==best_power&&i_bin<best_bin));
 always_ff @(posedge clk)begin
  if(rst)begin
   seen<=0;prev_valid<=0;left_valid<=0;right_valid<=0;
   best_bin<=0;prev_bin<=0;best_power<=0;prev_power<=0;left_power<=0;right_power<=0;
  end else if(i_valid)begin
   prev_bin<=i_bin;prev_power<=i_power;prev_valid<=1;
   if(i_sop)begin
    seen<=eligible;best_bin<=i_bin;best_power<=i_power;
    left_valid<=0;right_valid<=0;left_power<=0;right_power<=0;
   end else if(better)begin
    seen<=1;best_bin<=i_bin;best_power<=i_power;left_power<=prev_power;
    left_valid<=prev_valid&&(i_bin!=0)&&(prev_bin==i_bin-1'b1);
    right_valid<=0;right_power<=0;
   end else if(seen&&(i_bin==best_bin+1'b1))begin right_power<=i_power;right_valid<=1;end
  end
 end
 typedef enum logic[3:0] {IDLE,NORM,MUL,LOG_BIT,CALC,DIV_INIT,DIVIDE,FINISH} state_t;
 state_t state;
 logic [40:0] powers[0:2];logic [21:0] logs[0:2];
 logic [1:0] side;logic [5:0] exponent,msb;logic [4:0] log_step;
 logic [24:0] x,normalized;logic [49:0] square;logic [15:0] fraction;
 logic signed [22:0] numerator;logic signed [23:0] denominator;
 logic [37:0] dividend,quotient;logic [24:0] remainder;
 logic [23:0] divisor;logic [5:0] div_step;logic negative;
 wire [15:0] fraction_next={fraction[14:0],square[49]};
 wire [24:0] trial={remainder[23:0],dividend[37]};
 wire [37:0] quotient_next={quotient[36:0],trial>={1'b0,divisor}};
 wire [22:0] abs_num=numerator[22] ? -numerator : numerator;
 always_comb begin
  msb=0;
  for(integer j=0;j<41;j=j+1)if(powers[side][j])msb=6'(j);
  normalized=msb>24 ? 25'(powers[side]>>(msb-24)) : 25'(powers[side]<<(24-msb));
 end
 always_ff @(posedge clk)begin
  if(rst)begin
   state<=IDLE;o_done<=0;o_delta_q16<=0;o_status<=1;side<=0;exponent<=0;log_step<=0;
   x<=0;square<=0;fraction<=0;numerator<=0;denominator<=0;
   dividend<=0;quotient<=0;remainder<=0;divisor<=0;div_step<=0;negative<=0;
   for(integer j=0;j<3;j=j+1)begin powers[j]<=0;logs[j]<=0;end
  end else begin
   o_done<=0;
   case(state)
    IDLE:if(i_peak_valid)begin
     o_delta_q16<=0;o_status<=0;
     powers[0]<=left_power;powers[1]<=best_power;powers[2]<=right_power;side<=0;
     if(!i_enable)begin o_status<=1;state<=FINISH;end
     else if(!seen||!left_valid||!right_valid||best_bin!=i_peak_bin||best_power!=i_peak_power)
      begin o_status<=2;state<=FINISH;end
     else if(left_power==0||best_power==0||right_power==0)begin o_status<=3;state<=FINISH;end
     else if(best_power<left_power||best_power<right_power)begin o_status<=4;state<=FINISH;end
     else state<=NORM;
    end
    NORM:begin x<=normalized;exponent<=msb;fraction<=0;log_step<=0;state<=MUL;end
    MUL:begin square<=x*x;state<=LOG_BIT;end
    LOG_BIT:begin
     x<=square[49] ? square[49:25] : square[48:24];fraction<=fraction_next;
     if(log_step==15)begin
      logs[side]<={exponent,fraction_next};
      if(side==2)state<=CALC;else begin side<=side+1'b1;state<=NORM;end
     end else begin log_step<=log_step+1'b1;state<=MUL;end
    end
    CALC:begin
     numerator<=$signed({1'b0,logs[0]})-$signed({1'b0,logs[2]});
     denominator<=$signed({2'b0,logs[0]})-($signed({2'b0,logs[1]})<<<1)+$signed({2'b0,logs[2]});
     state<=DIV_INIT;
    end
    DIV_INIT:begin
     if(denominator>=0)begin o_status<=5;state<=FINISH;end
     else begin
      divisor<=-denominator;dividend<={abs_num,15'b0};negative<=!numerator[22];
      remainder<=0;quotient<=0;div_step<=0;state<=DIVIDE;
     end
    end
    DIVIDE:begin
     dividend<={dividend[36:0],1'b0};quotient<=quotient_next;
     remainder<=trial>={1'b0,divisor} ? trial-{1'b0,divisor} : trial;
     if(div_step==37)begin
      if(quotient_next>38'd32768)o_delta_q16<=negative ? -32'sd32768 : 32'sd32768;
      else o_delta_q16<=negative ? -$signed({16'b0,quotient_next[15:0]}) : $signed({16'b0,quotient_next[15:0]});
      state<=FINISH;
     end else div_step<=div_step+1'b1;
    end
    FINISH:begin o_done<=1;state<=IDLE;end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
