// Signed ADC * signed Q1.15 reference. Round to nearest (ties towards +inf),
// then saturate to the existing signed16 CIC input. Three registered stages.
module MainDigitalMixer(input logic clk,rst,i_frame_start,i_valid,
 input logic signed [15:0] i_rx,i_reference,
 output logic o_valid,output logic signed [15:0] o_sample,
 output logic o_clipped);
 logic valid_input,valid_product;
 logic signed [15:0] rx_registered,reference_registered;
 logic signed [31:0] product;
 // Unconditional data registers allow input/output registers to pack in the DSP.
 // Valid bits flush the pipeline; invalid data do not need reset/enable muxes.
 always_ff @(posedge clk)begin
  rx_registered<=i_rx;reference_registered<=i_reference;
  product<=$signed(rx_registered)*$signed(reference_registered);
 end
 wire signed [32:0] rounded=$signed({product[31],product})+33'sd16384;
 wire signed [32:0] scaled=rounded>>>15;
 always_ff @(posedge clk)begin
  if(rst||i_frame_start)begin
   valid_input<=0;valid_product<=0;o_valid<=0;o_sample<=0;o_clipped<=0;
  end else begin
   valid_input<=i_valid;valid_product<=valid_input;o_valid<=valid_product;
   if(valid_product)begin
    if(scaled>32767)begin o_sample<=32767;o_clipped<=1;end
    else if(scaled< -32768)begin o_sample<=-32768;o_clipped<=1;end
    else o_sample<=scaled[15:0];
   end
  end
 end
endmodule